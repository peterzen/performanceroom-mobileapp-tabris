//
//  TestTabrisClientDelegate.m
//  Tabris
//
//  Created by Jordi Böhme López on 16.01.15.
//  Copyright (c) 2015 EclipseSource. All rights reserved.
//

#import "TestTabrisClientDelegate.h"

@implementation TestTabrisClientDelegate

@synthesize serverURL = _serverURL;

- (instancetype)initWithURL:(NSURL *)serverURL {
    self = [super init];
    if (self) {
        _serverURL = serverURL;
    }
    return self;
}

- (NSURL *)serverURL {
    return _serverURL;
}

- (void)clientDidBecomeReady {
    //noop
}

@end
