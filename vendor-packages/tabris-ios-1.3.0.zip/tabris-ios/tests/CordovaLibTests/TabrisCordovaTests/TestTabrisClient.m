//
//  TestTabrisClient.m
//  Tabris
//
//  Created by Jordi Böhme López on 16.01.15.
//  Copyright (c) 2015 EclipseSource. All rights reserved.
//

#import <objc/runtime.h>
#import "TestTabrisClient.h"
#import "TestTabrisClientDelegate.h"

@interface TestTabrisClient ()
@property (strong, readonly) TestTabrisClientDelegate *testDelegate;
@property (strong) NSMutableDictionary *invocationCallbacks;
@end

@implementation TestTabrisClient

@synthesize testDelegate = _testDelegate;
@synthesize invocationCallbacks = _invocationCallbacks;

- (instancetype)initWithURL:(NSURL *)serverURL {
    _testDelegate = [[TestTabrisClientDelegate alloc] initWithURL:serverURL];
    self = [self initWithWindow:nil];
    if (self) {
        _invocationCallbacks = [NSMutableDictionary dictionary];
    }
    return self;
}

- (id<TabrisClientDelegate>)delegate {
    return _testDelegate;
}

- (void)load {
    [self selectorInvoked:_cmd];
    [super load];
}

- (void)invoking:(NSString *)selector executes:(void (^)())block {
    if( ![self.invocationCallbacks objectForKey:selector] ) {
        [self.invocationCallbacks setObject:[NSMutableArray array] forKey:selector];
    }
    [[self.invocationCallbacks objectForKey:selector] addObject:block];
}

- (void)selectorInvoked:(SEL)selector {
    NSString *selectorName = NSStringFromSelector(selector);
    NSArray *blocks = [self.invocationCallbacks objectForKey:selectorName];
    if( blocks ) {
        for (dispatch_block_t block in blocks) {
            block();
        }
    }
}

@end