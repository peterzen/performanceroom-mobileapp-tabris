//
//  WebViewProxy_Tests.m
//  Tabris
//
//  Created by Jordi Böhme López on 28.11.14.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/WebViewProxy.h>
#import <Tabris/Notifications.h>

@interface WebViewProxy_Tests : XCTestCase

@end

@implementation WebViewProxy_Tests

- (void)testWebViewProxyInitialization {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 20, 30, 40)];
    JSBinding *binding = [[JSBinding alloc] initWithClient:nil];

    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:view andJSBinding:binding andBaseURL:nil];

    XCTAssertTrue([proxy isKindOfClass:[WebViewProxy class]]);
    XCTAssertTrue([proxy isKindOfClass:[UIView class]]);
    XCTAssertTrue([proxy isKindOfClass:[UIWebView class]]);
}

- (void)testUIViewFrame {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 20, 30, 40)];
    JSBinding *binding = [[JSBinding alloc] initWithClient:nil];

    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:view andJSBinding:binding andBaseURL:nil];

    CGRect frame = [(UIWebView *)proxy frame];
    XCTAssertTrue( CGRectEqualToRect(frame, CGRectMake(10, 20, 30, 40)) );
}

- (void)testUIViewBounds {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 20, 30, 40)];
    JSBinding *binding = [[JSBinding alloc] initWithClient:nil];

    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:view andJSBinding:binding andBaseURL:nil];

    CGRect bounds = [(UIWebView *)proxy bounds];
    XCTAssertTrue( CGRectEqualToRect(bounds, CGRectMake(0, 0, 30, 40)) );
}

- (void)testUIWebViewEvaluateJavaScript {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 20, 30, 40)];
    JSBinding *binding = [[JSBinding alloc] initWithClient:nil];

    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:view andJSBinding:binding andBaseURL:nil];

    XCTAssertEqualObjects( [(UIWebView *)proxy stringByEvaluatingJavaScriptFromString:@"1+2"], @"3" );
}

- (void)testUIWebViewRequest {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 20, 30, 40)];
    JSBinding *binding = [[JSBinding alloc] initWithClient:nil];
    NSURL *baseURL = [NSURL URLWithString:@"file://base/url/package.json"];
    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:view andJSBinding:binding andBaseURL:baseURL];

    NSURLRequest *request = [(UIWebView *)proxy request];

    XCTAssertEqualObjects( [request.URL absoluteString], @"file://base/url/package.json" );
}

- (void)testUIWebViewEvaluateJavaScriptFiresTabrisEventToFlushEventQueue {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(10, 20, 30, 40)];
    JSBinding *binding = [[JSBinding alloc] initWithClient:nil];
    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:view andJSBinding:binding andBaseURL:nil];
    __block BOOL called = NO;
    [[NSNotificationCenter defaultCenter] addObserverForName:@"com.eclipsesource.tabris.ProcessingFinished" object:nil queue:nil usingBlock:^(NSNotification *note) {
        called = YES;
    }];
    NSString *result = [(UIWebView *)proxy stringByEvaluatingJavaScriptFromString:@"1+2"];

    XCTAssertEqualObjects( result, @"3" );
    XCTAssertTrue( called );
}

@end