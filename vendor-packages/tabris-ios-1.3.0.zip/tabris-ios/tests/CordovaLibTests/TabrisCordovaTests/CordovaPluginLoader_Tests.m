//
//  CordovaPluginLoader_Tests.m
//  Tabris
//
//  Created by Jordi Böhme López on 28.11.14.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/CordovaPluginLoader.h>
#import "TestPlugin.h"

@interface CordovaPluginLoader ()
@property (strong) WebViewProxy *webViewProxy;
- (NSMutableDictionary *)pluginRegistry;
- (NSMutableDictionary *)plugins;
@end

@interface CordovaPluginLoader_Tests : XCTestCase
@end

@implementation CordovaPluginLoader_Tests

- (void)tearDown {
    [super tearDown];
    [[[CordovaPluginLoader alloc] initWithWebView:nil] unload:@"testplugin.id"];
}

- (void)testInitialization {
    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:nil andJSBinding:nil andBaseURL:nil];

    CordovaPluginLoader *loader = [[CordovaPluginLoader alloc] initWithWebView:proxy];

    XCTAssertNotNil(loader.pluginRegistry);
    XCTAssertNotNil(loader.plugins);
    XCTAssertEqual(loader.webViewProxy, proxy);
}

- (void)testLoadPlugin {
    CordovaPluginLoader *loader = [[CordovaPluginLoader alloc] initWithWebView:nil];
    [[loader pluginRegistry] setObject:@"TestPlugin" forKey:@"testplugin.id"];

    CDVPlugin *plugin = [loader load:@"testplugin.id"];

    XCTAssertNotNil(plugin);
    XCTAssertTrue([plugin isKindOfClass:[TestPlugin class]]);
}

- (void)testLoadPluginTwiceReturnsSameInstance {
    CordovaPluginLoader *loader = [[CordovaPluginLoader alloc] initWithWebView:nil];
    [[loader pluginRegistry] setObject:@"TestPlugin" forKey:@"Test"];

    CDVPlugin *plugin1 = [loader load:@"Test"];
    CDVPlugin *plugin2 = [loader load:@"Test"];

    XCTAssertEqual(plugin1, plugin2);
}

- (void)testPluginIsInstantiatedWithWebViewProxy {
    WebViewProxy *proxy = [[WebViewProxy alloc] initWithView:nil andJSBinding:nil andBaseURL:nil];
    CordovaPluginLoader *loader = [[CordovaPluginLoader alloc] initWithWebView:proxy];
    [[loader pluginRegistry] setObject:@"TestPlugin" forKey:@"testplugin.id"];

    CDVPlugin *plugin = [loader load:@"testplugin.id"];

    XCTAssertNotNil(plugin.webView);
    XCTAssertEqual((id)plugin.webView, (id)proxy);
}

- (void)testLoadUnknownPluginReturnsNil {
    CordovaPluginLoader *loader = [[CordovaPluginLoader alloc] initWithWebView:nil];

    CDVPlugin *plugin = [loader load:@"foobar"];

    XCTAssertNil(plugin);
}

@end