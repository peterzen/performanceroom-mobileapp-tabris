//
//  AppManager_Test.m
//  Tabris
//
//  Created by Jordi Böhme López on 07.11.2014.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/AppManager.h>
#import <Cordova/AppManagerStore.h>
#import "TestTabrisClient.h"

@interface AppManager_Test : XCTestCase
@end

@interface AppManager ()
- (SEL)selectorForExecuteMethod:(NSString *)method;
@end

@implementation AppManager_Test

- (void)setUp {
    [super setUp];
    [AppManagerStore sharedStore].home = [[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"js/package.json"];
    [AppManagerStore sharedStore].current = nil;
}

- (void)testInit {
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:nil];

    XCTAssertNotNil(manager);
    XCTAssertTrue([manager isMemberOfClass:[AppManager class]]);
}

- (void)testRemoteObjectType {
    NSString *type = [AppManager remoteObjectType];
    XCTAssertEqualObjects(type, @"tabris.AppManager");
}

- (void)testListAvailableObjectProperties {
    NSSet *properties = [AppManager remoteObjectProperties];
    XCTAssertTrue([properties count] == 1, @"Properties test is incomplete");
    XCTAssertTrue([properties containsObject:@"current"]);
}

- (void)testCurrentIsHomeByDefault {
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:nil];
    XCTAssertEqualObjects(manager.current, [[AppManagerStore sharedStore].home absoluteString]);
}

- (void)testHasHomeMethod {
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:nil];

    XCTAssertTrue([manager selectorForExecuteMethod:@"home"] != nil);
}

- (void)testCallingHomeSetsHomeUrlAsCurrentAndReloadsTheClient {
    NSURL *entryURL = [NSURL URLWithString:@"file:///app/root/www/package.json"];
    TestTabrisClient *testClient = [[TestTabrisClient alloc] initWithURL:entryURL];
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:testClient];
    __block BOOL reloaded = NO;
    [testClient invoking:@"load" executes:^() {reloaded = YES;}];
    [AppManagerStore sharedStore].current = @"currentURL";

    [manager home:@{}];

    XCTAssertTrue(reloaded);
    XCTAssertNotNil(manager.current);
    XCTAssertNotEqualObjects(manager.current, @"currentURL");
    XCTAssertEqualObjects(manager.current, [[AppManagerStore sharedStore].home absoluteString]);
}

- (void)testSetCurrentReloadsTheClient {
    NSURL *entryURL = [NSURL URLWithString:@"file:///app/root/www/package.json"];
    TestTabrisClient *testClient = [[TestTabrisClient alloc] initWithURL:entryURL];
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:testClient];
    __block BOOL reloaded = NO;
    [testClient invoking:@"load" executes:^() {reloaded = YES;}];

    manager.current = @"currentURL";

    XCTAssertTrue(reloaded);
}

- (void)testSetCurrentAsAbsoluteURL {
    NSURL *entryURL = [NSURL URLWithString:@"file:///app/root/www/package.json"];
    TestTabrisClient *testClient = [[TestTabrisClient alloc] initWithURL:entryURL];
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:testClient];

    manager.current = @"http://server/path/package.json";

    XCTAssertEqualObjects(manager.current, @"http://server/path/package.json");
}

- (void)testSetCurrentAsRelativeURLResolvesURL {
    NSURL *entryURL = [NSURL URLWithString:@"file:///app/root/www/package.json"];
    TestTabrisClient *testClient = [[TestTabrisClient alloc] initWithURL:entryURL];
    AppManager *manager = [AppManager newObjectWithId:@"o1" properties:nil andClient:testClient];

    manager.current = @"subpath/package.json";

    XCTAssertEqualObjects(manager.current, @"file:///app/root/www/subpath/package.json");
}

@end