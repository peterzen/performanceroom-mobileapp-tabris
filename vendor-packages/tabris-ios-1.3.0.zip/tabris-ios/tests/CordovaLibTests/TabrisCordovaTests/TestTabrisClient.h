//
//  TestTabrisClient.h
//  Tabris
//
//  Created by Jordi Böhme López on 16.01.15.
//  Copyright (c) 2015 EclipseSource. All rights reserved.
//

#import <Tabris/TabrisClient.h>

@interface TestTabrisClient : TabrisClient

- (instancetype)initWithURL:(NSURL *)serverURL;
- (void)invoking:(NSString *)selector executes:(void (^)())block;

@end
