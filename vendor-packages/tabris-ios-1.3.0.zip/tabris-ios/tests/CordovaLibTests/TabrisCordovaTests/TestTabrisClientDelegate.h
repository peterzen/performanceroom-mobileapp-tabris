//
//  TestTabrisClientDelegate.h
//  Tabris
//
//  Created by Jordi Böhme López on 16.01.15.
//  Copyright (c) 2015 EclipseSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Tabris/TabrisClientDelegates.h>

@interface TestTabrisClientDelegate : NSObject<TabrisClientDelegate>
- (instancetype)initWithURL:(NSURL *)serverURL;
@property (strong, readonly) NSURL *serverURL;
@end
