//
//  TestNotifications.m
//  Tabris
//
//  Created by Jordi Böhme López on 20.11.12.
//  Copyright (c) 2012-2013 EclipseSource. All rights reserved.
//

#import "TestNotifications.h"

@interface Message ()
- (void)send;
@end

@implementation TestNotifications

static NSMutableArray *messages = nil;

+ (void)initMessages {
    if( !messages ) {
        messages = [[NSMutableArray alloc] init];
    }
}

+ (void)clear {
    if( messages ) {
        [messages removeAllObjects];
    }
}

+ (NSArray *)messages {
    return messages;
}

+ (Message<HeadNotification> *)forHead {
    [self initMessages];
    Message<HeadNotification> *message = [super forHead];
    [messages addObject:message];
    return message;
}

+ (Message<Notification> *)forObject:(id<RemoteObject>)target {
    [self initMessages];
    Message<Notification> *message = [super forObject:target];
    [messages addObject:message];
    return message;
}

+ (Message<Notification> *)forType:(NSString *)target {
    [self initMessages];
    Message<Notification> *message = [super forType:target];
    [messages addObject:message];
    return message;
}

@end
