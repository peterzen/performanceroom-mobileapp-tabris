//
//  TestPlugin.h
//  Tabris
//
//  Created by Jordi Böhme López on 28.11.14.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/CDVPlugin.h>
#import <Cordova/CDVInvokedUrlCommand.h>

@interface TestPlugin : CDVPlugin
@property (strong, readonly) CDVInvokedUrlCommand *lastCommand;
@property (assign, readonly) BOOL pluginInitialized;
- (void)myAction:(CDVInvokedUrlCommand *)command;
@end
