//
//  CordovaPluginBridge_Tests.m
//  Tabris
//
//  Created by Jordi Böhme López on 28.11.14.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/CDVPlugin.h>
#import <Cordova/CDVInvokedUrlCommand.h>
#import <Cordova/CDVUserAgentUtil.h>
#import <Cordova/CordovaPluginBridge.h>
#import <Cordova/CordovaPluginLoader.h>
#import <Cordova/WebViewProxy.h>
#import "TestPlugin.h"
#import "TestNotifications.h"

@interface CordovaPluginBridge ()
@property (strong) CDVPlugin *plugin;
@property (strong) CordovaPluginLoader *pluginLoader;
@property (weak, readonly) JSBinding *jsBinding;
- (SEL)selectorForExecuteMethod:(NSString *)method;
@end

@interface CordovaPluginLoader ()
- (NSMutableDictionary *)plugins;
- (NSMutableDictionary *)pluginRegistry;
@end

@interface CordovaPluginBridge_Tests : XCTestCase
@end

@implementation CordovaPluginBridge_Tests

- (void)setUp {
    [TestNotifications clear];
}

- (void)tearDown {
    [super tearDown];
    [[[CordovaPluginLoader alloc] initWithWebView:nil] unload:@"testplugin.id"];
}

- (void)testInitialization {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];

    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];

    XCTAssertFalse(bridge.finishListener);
    XCTAssertNotNil(bridge.settings);
    XCTAssertNotNil(bridge.jsBinding);
    XCTAssertNotNil(bridge.pluginLoader);
}

- (void)testRemoteObjectType {
    NSString *type = [CordovaPluginBridge remoteObjectType];
    XCTAssertEqualObjects(type, @"cordova.plugin");
}

- (void)testObjectPropertiesWhitelist {
    NSSet *properties = [CordovaPluginBridge remoteObjectProperties];
    XCTAssertTrue([properties containsObject:@"service"]);
}

- (void)testJSBrideFindsAndReturnsSameInstance {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];

    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];

    XCTAssertNotNil(bridge.jsBinding);
    XCTAssertEqual(bridge.jsBinding, bridge.jsBinding);
}

- (void)testSetServiceToLoadAndConfigureAPlugin {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];
    [[bridge.pluginLoader pluginRegistry] setObject:@"TestPlugin" forKey:@"testplugin.id"];

    bridge.service = @"testplugin.id";

    TestPlugin *plugin = (TestPlugin *)bridge.plugin;
    XCTAssertTrue(plugin.pluginInitialized);
    XCTAssertEqual(plugin.commandDelegate, bridge);
    XCTAssertEqual(plugin.viewController, [client viewController]);
}

- (void)testHasExecMethod {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];

    XCTAssertTrue([bridge selectorForExecuteMethod:@"exec"] != nil);}

- (void)testExec {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];
    TestPlugin *plugin = [[TestPlugin alloc] initWithWebView:nil];
    bridge.plugin = plugin;

    NSDictionary *parameters = @{@"action":@"myAction",@"arguments":@[@1,@"abc",@YES],@"callbackId":@"cbID001"};
    [bridge exec:parameters];

    NSArray *arguments = @[@1,@"abc",@YES];
    XCTAssertEqualObjects(plugin.lastCommand.arguments, arguments);
    XCTAssertEqualObjects(plugin.lastCommand.callbackId, @"cbID001");
    XCTAssertEqualObjects(plugin.lastCommand.methodName, @"myAction");
}

- (void)testSendPluginResultWithStatusAndNullMessage {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];
    bridge.notifications = [TestNotifications class];
    bridge.finishListener = YES;

    [bridge sendPluginResult:[CDVPluginResult resultWithStatus:CDVCommandStatus_OK] callbackId:@"cbID001"];

    Message<Notification> *message = [[TestNotifications messages] objectAtIndex:0];

    XCTAssertTrue([TestNotifications messages].count == 1);
    NSArray *operations = [message getMessageOperations];
    NSDictionary *event = @{@"callbackId":@"cbID001", @"keepCallback":@NO, @"message":[NSNull null], @"status":@1};
    NSString *expected = [NSString stringWithFormat:@"notify: finish, %@", event];
    XCTAssertEqualObjects([[operations objectAtIndex:0] description], expected);
}

- (void)testSendPluginResultWithMessage {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];
    bridge.notifications = [TestNotifications class];
    bridge.finishListener = YES;

    NSDictionary *message = @{@"key1":@"value", @"key2":@NO};
    [bridge sendPluginResult:[CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:message] callbackId:@"cbID002"];

    Message<Notification> *notification = [[TestNotifications messages] objectAtIndex:0];

    XCTAssertTrue([TestNotifications messages].count == 1);
    NSArray *operations = [notification getMessageOperations];
    NSDictionary *event = @{@"callbackId":@"cbID002", @"keepCallback":@NO, @"message":@{@"key1":@"value", @"key2":@NO}, @"status":@1};
    NSString *expected = [NSString stringWithFormat:@"notify: finish, %@", event];
    XCTAssertEqualObjects([[operations objectAtIndex:0] description], expected);
}

- (void)testDontSendPluginResultWithNoFinishListener {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];
    bridge.notifications = [TestNotifications class];
    bridge.finishListener = NO;

    [bridge sendPluginResult:[CDVPluginResult resultWithStatus:CDVCommandStatus_OK] callbackId:@"callbackId"];

    XCTAssertTrue([TestNotifications messages].count == 0);
}

- (void)testDontSendPluginResultWithINVALIDCallback {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];
    bridge.notifications = [TestNotifications class];
    bridge.finishListener = YES;

    [bridge sendPluginResult:[CDVPluginResult resultWithStatus:CDVCommandStatus_OK] callbackId:@"INVALID"];

    XCTAssertTrue([TestNotifications messages].count == 0);
}

- (void)testRunInBackgroundSimplyExecutesTheCode {
    XCTestExpectation *expectation = [self expectationWithDescription:@"block must run in background"];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];

    [bridge runInBackground:^{
        [expectation fulfill];
    }];

    [self waitForExpectationsWithTimeout:0 handler:^(NSError *error) {
        XCTAssertNil(error);
    }];
}

- (void)testUserAgent {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];

    NSString *userAgent = [bridge userAgent];

    XCTAssertNotNil(userAgent);
}

- (void)testGetCommandInstance {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];
    CDVPlugin *plugin = [[CDVPlugin alloc] initWithWebView:nil];
    [[bridge.pluginLoader plugins] setObject:plugin forKey:@"Name"];

    id instance = [bridge getCommandInstance:@"Name"];

    XCTAssertEqual(instance, plugin);
}

- (void)testUseSameInstanceOfLoadedPlugins {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge1 = [[CordovaPluginBridge alloc] initWithObjectId:@"oid1" andClient:client];
    CDVPlugin *plugin = [[CDVPlugin alloc] initWithWebView:nil];
    [bridge1.pluginLoader.plugins setObject:plugin forKey:@"Plugin1"];

    CordovaPluginBridge *bridge2 = [[CordovaPluginBridge alloc] initWithObjectId:@"oid2" andClient:client];
    id instance = [bridge2 getCommandInstance:@"Plugin1"];

    XCTAssertNotNil([bridge1 getCommandInstance:@"Plugin1"]);
    XCTAssertEqual(instance, plugin);
}

- (void)testDestroyUnloadsPluginInstance {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid1" andClient:client];
    bridge.service = @"Plugin1";
    CDVPlugin *plugin = [[CDVPlugin alloc] initWithWebView:nil];
    [bridge.pluginLoader.plugins setObject:plugin forKey:@"Plugin1"];

    [bridge destroy];

    XCTAssertNil([bridge getCommandInstance:@"Plugin1"]);
}

- (void)testPathForResourceAlwaysReturnsNil {
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:nil];

    NSString *path = [bridge pathForResource:@"foobar"];

    XCTAssertNil(path);
}

- (void)testEvalJS {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];

    [bridge evalJs:@"result = 40 + 2;"];

    XCTAssertEqualObjects([[bridge.jsBinding execute:@"result;" fromSourceURL:nil] toString], @"42");
}

- (void)testEvalJSScheduledOnRunLoopExecutesInmediatly {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];

    [bridge evalJs:@"result = 40 + 2;" scheduledOnRunLoop:YES];

    XCTAssertEqualObjects([[bridge.jsBinding execute:@"result;" fromSourceURL:nil] toString], @"42");
}

- (void)testEvalJSNotScheduledOnRunLoop {
    TabrisClient *client = [[TabrisClient alloc] initWithWindow:nil andBindings:@[NSClassFromString(@"JSBinding")]];
    CordovaPluginBridge *bridge = [[CordovaPluginBridge alloc] initWithObjectId:@"oid" andClient:client];

    [bridge evalJs:@"result = 40 + 2;" scheduledOnRunLoop:NO];

    XCTAssertEqualObjects([[bridge.jsBinding execute:@"result;" fromSourceURL:nil] toString], @"42");
}

@end