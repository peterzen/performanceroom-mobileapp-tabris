//
//  AppManagerStore_Test.m
//  Tabris
//
//  Created by Jordi Böhme López on 07.11.2014.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/AppManagerStore.h>

@interface AppManagerStore_Test : XCTestCase
@end

@implementation AppManagerStore_Test

- (void)setUp {
    [super setUp];
    [AppManagerStore sharedStore].home = nil;
    [AppManagerStore sharedStore].current = nil;
}

- (void)testSingleton {
    AppManagerStore *manager1 = [AppManagerStore sharedStore];
    AppManagerStore *manager2 = [AppManagerStore sharedStore];

    XCTAssertNotNil(manager1);
    XCTAssertNotNil(manager2);
    XCTAssertEqual(manager1, manager2);
}

- (void)testHomeIsNilByDefault {
    AppManagerStore *manager = [AppManagerStore sharedStore];
    XCTAssertNil(manager.home);
}

- (void)testCurrentIsNilByDefault {
    AppManagerStore *manager = [AppManagerStore sharedStore];
    XCTAssertNil(manager.current);
}

- (void)testGetCurrentReturnsHomeByDefault {
    [AppManagerStore sharedStore].home = [[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"js/package.json"];
    AppManagerStore *manager = [AppManagerStore sharedStore];

    XCTAssertEqualObjects(manager.current, [manager.home absoluteString]);
}

- (void)testSetCurrent {
    AppManagerStore *manager = [AppManagerStore sharedStore];

    manager.current = @"http://localhost/current";

    XCTAssertEqualObjects(manager.current, @"http://localhost/current");
}

- (void)testSetCurrentBackToNilReturnsHome {
    AppManagerStore *manager = [AppManagerStore sharedStore];
    manager.current = @"http://localhost/current";

    manager.current = nil;

    XCTAssertEqualObjects(manager.current, [manager.home absoluteString]);
}

- (void)testUrlReturnsHomeByDefault {
    [AppManagerStore sharedStore].home = [[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"js/package.json"];
    AppManagerStore *manager = [AppManagerStore sharedStore];
    XCTAssertEqualObjects(manager.url, manager.home);
}

- (void)testThrowExceptionWhenAccessingTheUrlWithNoHomeConfigured {
    AppManagerStore *manager = [AppManagerStore sharedStore];
    XCTAssertThrows(manager.url);
}

- (void)testUrlReturnCurrentIfSet {
    [AppManagerStore sharedStore].home = [[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"js/package.json"];
    AppManagerStore *manager = [AppManagerStore sharedStore];

    manager.current = @"http://localhost/current";

    XCTAssertEqualObjects(manager.url, [NSURL URLWithString:@"http://localhost/current"]);
}

@end