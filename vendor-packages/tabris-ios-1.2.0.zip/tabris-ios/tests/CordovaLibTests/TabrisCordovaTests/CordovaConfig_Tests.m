//
//  CordovaConfig_Tests.m
//  Tabris
//
//  Created by Jordi Böhme López on 11.02.2015.
//  Copyright (c) 2015 EclipseSource. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <Cordova/CordovaConfig.h>
#import <Cordova/CDVConfigParser.h>
#import "TestPlugin.h"

@interface CDVConfigParser ()
@property (nonatomic, readwrite, strong) NSMutableDictionary* pluginsDict;
@property (nonatomic, readwrite, strong) NSMutableDictionary* settings;
@property (nonatomic, readwrite, strong) NSMutableArray* whitelistHosts;
@property (nonatomic, readwrite, strong) NSMutableArray* startupPluginNames;
@property (nonatomic, readwrite, strong) NSString* startPage;
@end

@interface CordovaConfig ()
@property (strong) CDVConfigParser *cdvConfig;
@end

@interface CordovaConfig_Tests : XCTestCase
@end

@implementation CordovaConfig_Tests

- (void)setUp {
    [super setUp];
    [CordovaConfig config].cdvConfig.startPage = nil;
}

- (void)testSingleton {
    CordovaConfig *instance = [CordovaConfig config];
    CordovaConfig *instance2 = [CordovaConfig config];

    XCTAssertNotNil(instance);
    XCTAssertEqual(instance, instance2);
}

- (void)testCDVConfigParserIsInitialized {
    CordovaConfig *config = [CordovaConfig config];

    XCTAssertNotNil(config.cdvConfig);
}

- (void)testDefaultPackageJsonPath {
    CordovaConfig *config = [CordovaConfig config];

    XCTAssertEqualObjects(config.packageJsonPath, @"package.json");
}

- (void)testConfiguredPackageJsonPath {
    CordovaConfig *config = [CordovaConfig config];
    config.cdvConfig.startPage = @"other/path/package.json";

    XCTAssertEqualObjects(config.packageJsonPath, @"other/path/package.json");
}

- (void)testInvalidConfiguredPackageJsonPath {
    CordovaConfig *config = [CordovaConfig config];
    config.cdvConfig.startPage = @"other/path/not.a.json";

    XCTAssertEqualObjects(config.packageJsonPath, @"package.json");
}

- (void)testConfiguredSettingsFromCDVConfigParser {
    CordovaConfig *config = [CordovaConfig config];
    NSMutableDictionary *settings = [NSMutableDictionary dictionary];
    config.cdvConfig.settings = settings;

    XCTAssertEqual(config.settings, settings);
}

- (void)testConfiguredPluginsFromCDVConfigParser {
    CordovaConfig *config = [CordovaConfig config];
    NSMutableDictionary *plugins = [NSMutableDictionary dictionary];
    config.cdvConfig.pluginsDict = plugins;

    XCTAssertEqual(config.plugins, plugins);
}

@end