//
//  TestPlugin.m
//  Tabris
//
//  Created by Jordi Böhme López on 28.11.14.
//  Copyright (c) 2014 EclipseSource. All rights reserved.
//

#import "TestPlugin.h"

@implementation TestPlugin

@synthesize pluginInitialized = _pluginInitialized;
@synthesize lastCommand = _lastCommand;

- (instancetype)init {
    self = [super init];
    if (self) {
        _pluginInitialized = NO;
        _lastCommand = nil;
    }
    return self;
}

- (void)pluginInitialize {
    _pluginInitialized = YES;
}

- (void)myAction:(CDVInvokedUrlCommand *)command {
    _lastCommand = command;
}

@end
