//
//  TestNotifications.h
//  Tabris
//
//  Created by Jordi Böhme López on 20.11.12.
//  Copyright (c) 2012-2013 EclipseSource. All rights reserved.
//

#import <Tabris/Notifications.h>

@interface TestNotifications : Notifications

+ (NSArray *)messages;
+ (void)clear;

@end
